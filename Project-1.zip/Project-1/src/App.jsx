import "./App.css";
import GroceryApp from "./GroceryApp";

function App() {
  return <>
  <GroceryApp />  
  </>;
}

export default App;
