import { products } from "./Data/products";

 import { useState } from "react";
import InventoryCard from "./InventoryCard";
import "./App.css";

export default function GroceryApp() {
  const [Cart, setCart] = useState([]);

  const addCart = (item) => {
    setCart((prevData) => {
      return ([...prevData, {...item }]);
    })
  }
  const deleteitem = (id) => {
    setCart((prevList) => {
      return prevList.filter((i) => i.id !== id);
    });
  };
  const deleteallitem = (id) => {
    setCart((prevList) => {
      return prevList.filter((i) => i.id == id);
    });
  };
  function TotalPrice(products) {
    return products.reduce((total,product) => {
      const price = parseFloat(product.price.replace('$',''));
      return total+price;
    }, 0);
  }


 

 

  return (


    <div className="GroceriesApp-Container">
      <div className="Inventory-Container ">
      {products.map((z) => (
        <div key={z.id}  className="Inventory-Card">
          <InventoryCard 
          productName = {z.productName}
          brand = {z.brand}
          quantity={z.quantity}
          price={z.price}
          image={z.image}
          />
          <button type="submit" onClick={() => addCart(z)}>Add</button>
          </div>
      ))}
      </div>


        <div className="CartList-Container">
        <h2>Cart</h2>
        {Cart.length === 0 ? (
          <h5> Your cart is Empty</h5>
        ):(
          Cart.map((z) => (
            <div key ={z.id}className="CartList-Card">
              <div className="CartList-Card-Info">
                <h2>{z.productName}</h2>
                <h2>{z.price}</h2>
              </div>
              <button className="Remove-Button" onClick={() => deleteitem(z.id)}>Remove Item </button>
            </div>
          ))
        )}

        <div className="CartList-Button">
          <button className="Remove-Button"onClick={deleteallitem}>
          empty cart
          </button>
          <button className="Buy-Button" onClick={TotalPrice}>
            Total : ${TotalPrice(Cart)}
          </button>
        </div>


        </div>

      </div>
  )
          }
        
    



