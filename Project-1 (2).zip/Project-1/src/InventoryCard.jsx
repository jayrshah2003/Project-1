
export default function InventoryCard({image,productName,brand,quantity,price}){

    
    //const style = rating >= 4.0 ? {color:"green"} : {color:"red"};
    
return(
    <div className="InventoryCard">
    <img src={image} alt="productName" />
    <h1>{productName}</h1>
    <h3>{brand}</h3>
    <h4>{quantity}</h4>
    <p>{price}</p>

    </div>
)
}